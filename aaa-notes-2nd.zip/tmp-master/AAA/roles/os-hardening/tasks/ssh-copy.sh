#!/bin/bash

remotehosts="$1"
username="anxxxx"
password="password"

for host in `cat ${remotehosts}`
do
sshpass -p${password} ssh-copy-id -o StrictHostKeyChecking=no ${username}@${host}
echo "Uploaded key to " ${host}
done

echo "Finished!"