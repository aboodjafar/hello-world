#!/bin/bash
DATE=`date +'%m%d%y%H%M'`  >> /usr/local/etc/EOD_RSYNC.LOG
echo "====================================================="  >> /usr/local/etc/EOD_RSYNC.LOG
echo "$DATE1 - Start CPMS Files RSYNC From UTHQRHD2AP101 to UA0RHD2AP101"  >> /usr/local/etc/EOD_RSYNC.LOG
echo "====================================================="  >> /usr/local/etc/EOD_RSYNC.LOG
rsync -avz uthqrhd2ap101.ace.aaaclubnet.com:/home/apd/ACE/data/* /home/apd/ACE/data/ >> /usr/local/etc/EOD_RSYNC.LOG
rsync -avz uthqrhd2ap101.ace.aaaclubnet.com:/home/apd/ACE/output/* /home/apd/ACE/output/ >> /usr/local/etc/EOD_RSYNC.LOG
rsync -avz uthqrhd2ap101.ace.aaaclubnet.com:/home/ftp/pub/* /home/ftp/pub/ >> /usr/local/etc/EOD_RSYNC.LOG
rsync -avz --exclude-from=/usr/local/etc/EODEXCLUDES uthqrhd2ap101.ace.aaaclubnet.com:/home/apd/ACE/bin/eod/* /home/apd/ACE/bin/eod/ >> /usr/local/etc/EOD_RSYNC.LOG
rsync -avz uthqrhd2ap101.ace.aaaclubnet.com:/home/d2000/ACE/output/*  /home/d2000/ACE/output/ >> /usr/local/etc/EOD_RSYNC.LOG
echo "====================================================="  >> /usr/local/etc/EOD_RSYNC.LOG
echo "$DATE - Done  RSYNC from UTHQRHD2AP101 to UA0RHD2AP101"  >> /usr/local/etc/EOD_RSYNC.LOG
echo "====================================================="  >> /usr/local/etc/EOD_RSYNC.LOG
exit
